{-# LANGUAGE DeriveDataTypeable #-}
module ILInterface   
( 
buildJSON,
buildDealInfo

) where 
import Control.Applicative
import Text.JSON
import Text.JSON.Generic
import Text.JSON.Types
import Control.Monad 
import MyJSON
import Types
import Formulas
import Models
import PayOffs
import FinantialConventions
import Currencies

    
------------------------------ IL 2 JSON issues --------------------------------------         
-- First change ' by "
-- JSON only admits strings like keys, change key legs (0,0) and (0,1) by "(0,0)" and "(0,1)"
-- The same with CMS_DATES_DICT, change numbers by strings
-- The same with HISTORIC_FIXINGS_DICT
-- Substitute symbol ( of tuples with symbol [ of lists in operators.
-- In operators we have "" inside a string, we have to scape them

--------------------- Builders -------------------------------------------------------    
--------------------------------------------------------------------------------------
buildJSON :: String -> IO String
buildJSON path = do
    jsonIL <- readFile path
    let decodedIL = decode jsonIL :: Result (JSObject JSValue)   
    return (myEncodeJSON (buildInput =<< decodedIL))
-- ----------------------------------
buildInput :: JSObject JSValue -> Result Input
buildInput jsO = returnInput deal mktData modelParams
    where deal = buildDeal jsO
          mktData = buildMktParams jsO
          modelParams = buildModelParams jsO deal
          returnInput :: Result Deal -> Result MarketData -> 
                         Result ModelParameters -> Result Input 
          returnInput rDl rMkD rMdP = do
              dl <- rDl
              mkD <- rMkD
              mdP <- rMdP
              return (Input {inputDeal = dl, inputMarket = mkD, inputModelParams = mdP})
-- ----------------------------------
buildDeal :: JSObject JSValue -> Result Deal
buildDeal jsO = returnDeal info prod
    where info = buildDealInfo jsO 
          prod = buildProduct jsO
          returnDeal :: Result DealInfo -> Result Product -> 
                        Result Deal
          returnDeal (Ok dI) (Ok pr) = Ok Deal {dealInfo = dI, dealProduct = pr}
          returnDeal x y = Error ((getErr x) ++ (getErr y))
-- ------------------------------------------
buildProduct :: JSObject JSValue -> Result Product
buildProduct jsO = returnProduct rTp
    where rTp = getValueJS jsO "DEAL/LEGS/(0, 0)/LOAN_PAYOUT" :: Result JSValue
          returnProduct :: Result JSValue -> Result Product
          returnProduct (Ok tP) 
              | typeProduct == 0 = buildSwap jsO 
              | typeProduct /= 0 = buildOption jsO 
              where typeProduct = read (encode tP) :: Int
          returnProduct x = Error (getErr x)
-- ------------------------------------------
buildSwap :: JSObject JSValue -> Result Product
buildSwap jsO = returnSwap typeLeg1 typeLeg2
    where typeLeg1 = getValueJS jsO "DEAL/LEGS/(0, 0)/LOAN_RATE_NATURE" :: Result JSValue
          typeLeg2 = getValueJS jsO "DEAL/LEGS/(0, 1)/LOAN_RATE_NATURE" :: Result JSValue
          returnSwap :: Result JSValue -> Result JSValue -> Result Product
          returnSwap rTl1 rTl2 = do
              tL1 <- rTl1 
              tL2 <- rTl2               
              returnSwap2 rL1 rL2
              where rL1 = buildLeg jsO 0
                    rL2 = buildLeg jsO 1
                    returnSwap2 :: Result Leg -> Result Leg -> Result Product 
                    returnSwap2 rL1 rL2 = do
                        l1 <- rL1
                        l2 <- rL2
                        return (Swap SwapGenerator l1 l2 (AddFlows []) )  
-- ------------------------------------------
buildOption :: JSObject JSValue -> Result Product
buildOption jsO = returnOption typeLeg
    where typeLeg = getValueJS jsO "DEAL/LEGS/(0, 0)/LOAN_RATE_NATURE" :: Result JSValue
          returnOption :: Result JSValue -> Result Product
          returnOption rTl = do
              tL <- rTl 
              returnOption2 rL
              where rL = buildLeg jsO 0
                    returnOption2 :: Result Leg -> Result Product 
                    returnOption2 rL = do
                        l <- rL
                        return (Option OptionGenerator l (AddFlows []) )  
                      
-- ------------------------------------------
buildLeg :: JSObject JSValue -> Int -> Result Leg
buildLeg jsO index = returnLeg rTypeLeg
    where path = "DEAL/LEGS/(0, " ++ (show index) ++ ")"          
          rTypeLeg = getFixedVariable >>= getTypeLeg
          returnLeg :: Result Int -> Result Leg
          returnLeg rTl = do
              tL <- rTl
              dispatch tL
          dispatch :: Int -> Result Leg
          dispatch 0 = buildFixedLeg jsO path
          dispatch 1 = buildLiborLeg jsO path
          dispatch 2 = buildCMSLeg jsO path
          rTypeLeg1 = getValueJS jsO (path ++ "/LOAN_RATE_NATURE") :: Result JSValue  
          getFixedVariable :: Result Int
          getFixedVariable = do
              typeLeg <- rTypeLeg1
              return (read (encode typeLeg) :: Int)
          getTypeLeg :: Int -> Result Int    
          getTypeLeg 0 = Ok 0
          getTypeLeg x = do 
              tL2 <- rTypeLeg2
              let tL2' = read (encode tL2) :: Int
              return (tL2' +1)
              where rTypeLeg2 = getValueJS jsO (path ++ "/INDEX_RATE_NATURE") :: Result JSValue
            
                    
-- ------------------------------------------
buildLiborLeg :: JSObject JSValue -> String -> Result Leg
buildLiborLeg jsO path = returnLiborLeg startDateCoup endDateCoup payDateCoup remCapCoup 
                                        basisCoup computeModeCoup fixingsLibor
                                        dataLibor basisLibor marginLibor 
                                        indexName discCurve payRec
    where startDateCoup = getArrayJS jsO (path ++ "/PERIOD_START_DATES") :: Result [JSValue]
          endDateCoup = getArrayJS jsO (path ++ "/PERIOD_END_DATES") :: Result [JSValue]
          payDateCoup = getArrayJS jsO (path ++ "/PERIOD_PAYMENT_DATES") :: Result [JSValue]
          remCapCoup = getArrayJS jsO (path ++ "/PERIOD_REMAINING_CAPITALS") :: Result [JSValue]
          basisCoup = getValueJS jsO (path ++ "/RATE_CONVENTION_BASIS") :: Result JSValue
          computeModeCoup = getValueJS jsO (path ++ "/RATE_CONVENTION_COMPUTING_MODE") :: Result JSValue
          fixingsLibor = getArrayJS jsO (path ++ "/PERIOD_FIXING_DATES") :: Result [JSValue]
          dataLibor = getLiborData jsO fixingsLibor path
          basisLibor = getValueJS jsO (path ++ "/INDEX_RATE_CONVENTION_BASIS") :: Result JSValue
          marginLibor = getArrayJS jsO (path ++ "/PERIOD_FLOATING_MARGINS") :: Result [JSValue]
          indexName = getValueJS jsO (path ++ "/INDEX_NAME") :: Result JSValue
          discCurve = getValueJS jsO ("DEAL/DISCOUNT_CURVE") :: Result JSValue
          payRec = getValueJS jsO (path ++ "/LOAN_PAYOUT_SIGN") :: Result JSValue
          returnLiborLeg :: Result [JSValue] -> Result [JSValue] -> Result [JSValue] ->
                            Result [JSValue] -> Result JSValue -> Result JSValue ->
                            Result [JSValue] -> Result ([JSValue], [JSValue], [JSValue]) -> 
                            Result JSValue -> Result [JSValue] ->
                            Result JSValue -> Result JSValue -> Result JSValue -> Result Leg
          returnLiborLeg rSDC rEDC rPDC rRCC rBC rCMC rFL rDL rBL rML rIN rDC rPR = do
              sDC <- rSDC 
              eDC <- rEDC 
              pDC <- rPDC 
              rCC <- rRCC 
              bC <- rBC 
              cMC <- rCMC 
              fL <- rFL 
              dL <- rDL 
              bL <- rBL
              mL <- rML 
              iN <- rIN 
              dC <- rDC 
              pR <- rPR 
              let sDC2 = read (encode sDC) :: [Int] 
              let eDC2 = read (encode eDC) :: [Int] 
              let pDC2 = read (encode pDC) :: [Int] 
              let rCC2 = read (encode rCC) :: [Double] 
              let bC2 = decodeBasis (read (encode bC) :: Int)
              let cMC2 = decodeComputeMode (read (encode cMC) :: Int)
              let fL2 = read (encode fL) :: [Int]      
              let sDL = (\(a,_,_) -> a) dL      
              let eDL = (\(_,a,_) -> a) dL      
              let pDL = (\(_,_,a) -> a) dL
              let sDL2 = read (encode sDL) :: [Int]     
              let eDL2 = read (encode eDL) :: [Int]     
              let pDL2 = read (encode pDL) :: [Int]      
              let bL2 = decodeBasis (read (encode bL) :: Int)
              let mL2 = read (encode mL) :: [Double]
              let iN2 = read (encode iN) :: String
              let dC2 = read (encode dC) :: String
              let pR2 = decodePayerReceiver (read (encode pR) :: Int)
              let couponsList = getZipList $ buildCoupon <$> ZipList sDC2 <*> ZipList eDC2 <*> ZipList pDC2 
                                         <*> ZipList rCC2 <*> ZipList (repeat bC2) <*> ZipList (repeat cMC2)
                                         <*> ZipList fL2 <*> ZipList sDL2 <*> ZipList eDL2 <*> ZipList pDL2 
                                         <*> ZipList (repeat bL2) <*> ZipList mL2
              return (VariableLeg {coupons = couponsList, discCurve = dC2, legIndex = iN2, legPayerReceiver = pR2})
              where
                  buildCoupon sDC eDC pDC rCC bC cMC fL sDL eDL pDL bL mL = returnCoupon sDC eDC pDC rCC bC cMC pO m
                      where 
                      pO = returnPayOff fL sDL eDL pDL bL mL
                      m = returnModel
                    
                  returnCoupon sDC eDC pDC rCC bC cMC pO m = Variable {cpStartDate = sDC, cpEndDate = eDC, cpPayDate = pDC, 
                                                               cpYearFrac = 0.0, cpRemainingCapital = rCC, cpConvention = (cMC, bC),
                                                               varPayOff = pO, varModel = m, varNum0 = 0.0}
                  returnPayOff fL sDL eDL pDL bL mL = Libor{liborFix = fL, liborStart = sDL, liborEnd = eDL, liborPay = pDL, 
                                                    liborConvention = (LIN, bL), margin = mL}
                  returnModel = Forward {forward = 0.0}
-- ------------------------------------------
getLiborData :: JSObject JSValue -> Result [JSValue] -> String -> 
                Result ([JSValue], [JSValue], [JSValue])
getLiborData jsO fixings path = returnLiborData fixings
    where returnLiborData :: Result [JSValue] -> 
                Result ([JSValue], [JSValue], [JSValue])
          returnLiborData rFx = do
              fx <- rFx
              let fx2 = read (encode fx) :: [Int]
              let startDate = fmap (getInfoLibor "CALC_DATE_1") fx2 
              let endDate = fmap (getInfoLibor "CALC_DATE_2") fx2 
              let payDate = fmap (getInfoLibor "PAYMENT_DATE_2") fx2 
              startDate2 <- (checkAllOk startDate)
              endDate2 <- (checkAllOk endDate)
              payDate2 <- checkAllOk payDate
              return (startDate2, endDate2, payDate2)
          getInfoLibor :: String -> Int -> Result JSValue              
          getInfoLibor field fx = getValueJS jsO (path ++ "/INDEX_COMPUTE_DATES/" ++ (show fx) ++ "/" ++ field) :: Result JSValue      
-- ------------------------------------------

buildCMSLeg :: JSObject JSValue -> String -> Result Leg
buildCMSLeg jsO path = returnCMSLeg startDateCoup endDateCoup payDateCoup remCapCoup 
                                        basisCoup computeModeCoup fixingsCMS
                                        datesCMS basisCMS marginCMS 
                                        indexName discCurve payRec modelLabel
    where startDateCoup = getArrayJS jsO (path ++ "/PERIOD_START_DATES") :: Result [JSValue]
          endDateCoup = getArrayJS jsO (path ++ "/PERIOD_END_DATES") :: Result [JSValue]
          payDateCoup = getArrayJS jsO (path ++ "/PERIOD_PAYMENT_DATES") :: Result [JSValue]
          remCapCoup = getArrayJS jsO (path ++ "/PERIOD_REMAINING_CAPITALS") :: Result [JSValue]
          basisCoup = getValueJS jsO (path ++ "/RATE_CONVENTION_BASIS") :: Result JSValue
          computeModeCoup = getValueJS jsO (path ++ "/RATE_CONVENTION_COMPUTING_MODE") :: Result JSValue
          fixingsCMS = getArrayJS jsO (path ++ "/PERIOD_FIXING_DATES") :: Result [JSValue]
          datesCMS = getCMSDates jsO fixingsCMS path
          basisCMS = getValueJS jsO (path ++ "/INDEX_RATE_CONVENTION_BASIS") :: Result JSValue
          marginCMS = getArrayJS jsO (path ++ "/PERIOD_FLOATING_MARGINS") :: Result [JSValue]
          indexName = getValueJS jsO (path ++ "/INDEX_NAME") :: Result JSValue
          discCurve = getValueJS jsO ("DEAL/DISCOUNT_CURVE") :: Result JSValue
          payRec = getValueJS jsO (path ++ "/LOAN_PAYOUT_SIGN") :: Result JSValue
          modelLabel = getValueJS jsO "DEAL/FLEX/0/BLOCK_LABEL" :: Result JSValue
          returnCMSLeg :: Result [JSValue] -> Result [JSValue] -> Result [JSValue] ->
                            Result [JSValue] -> Result JSValue -> Result JSValue ->
                            Result [JSValue] -> Result [[JSValue]] -> 
                            Result JSValue -> Result [JSValue] -> Result JSValue -> 
                            Result JSValue -> Result JSValue -> Result JSValue -> Result Leg
          returnCMSLeg rSDC rEDC rPDC rRCC rBC rCMC rFCMS rDCMS rBCMS rMCMS rIN rDC rPR rML = do
              sDC <- rSDC 
              eDC <- rEDC 
              pDC <- rPDC 
              rCC <- rRCC 
              bC <- rBC 
              cMC <- rCMC 
              fCMS <- rFCMS 
              dCMS <- rDCMS 
              bCMS <- rBCMS
              mCMS <- rMCMS 
              iN <- rIN 
              dC <- rDC 
              pR <- rPR
              mL <- rML
              let sDC2 = read (encode sDC) :: [Int] 
              let eDC2 = read (encode eDC) :: [Int] 
              let pDC2 = read (encode pDC) :: [Int] 
              let rCC2 = read (encode rCC) :: [Double] 
              let bC2 = decodeBasis (read (encode bC) :: Int)
              let cMC2 = decodeComputeMode (read (encode cMC) :: Int)
              let fCMS2 = read (encode fCMS) :: [Int]      
              let dCMS2 = read (encode dCMS) :: [[Int]]     
              let bCMS2 = decodeBasis (read (encode bCMS) :: Int)
              let mCMS2 = read (encode mCMS) :: [Double]
              let iN2 = read (encode iN) :: String
              let dC2 = read (encode dC) :: String
              let pR2 = decodePayerReceiver (read (encode pR) :: Int)
              let mL2 = decodeModel (read (encode mL) :: String)
              let couponsList = getZipList $ buildCoupon <$> ZipList sDC2 <*> ZipList eDC2 <*> ZipList pDC2 
                                         <*> ZipList rCC2 <*> ZipList (repeat bC2) <*> ZipList (repeat cMC2)
                                         <*> ZipList fCMS2 <*> ZipList dCMS2 
                                         <*> ZipList (repeat bCMS2) <*> ZipList mCMS2 <*> ZipList (repeat mL2)
              return (VariableLeg {coupons = couponsList, discCurve = dC2, legIndex = iN2, legPayerReceiver = pR2})
              where
                  buildCoupon sDC eDC pDC rCC bC cMC fCMS dCMS bCMS mCMS mlCMS = returnCoupon sDC eDC pDC rCC bC cMC pO mlCMS
                      where 
                      pO = returnPayOff fCMS dCMS bCMS mCMS
                    
                  returnCoupon sDC eDC pDC rCC bC cMC pO m = Variable {cpStartDate = sDC, cpEndDate = eDC, cpPayDate = pDC, 
                                                               cpYearFrac = 0.0, cpRemainingCapital = rCC, cpConvention = (cMC, bC),
                                                               varPayOff = pO, varModel = m, varNum0 = 0.0}
                  returnPayOff fCMS dCMS bCMS mCMS = CMS{cmsFix = fCMS, cmsDates = dCMS, cmsConvention = (LIN, bCMS), cmsMargin = mCMS}
-- ------------------------------------------
getCMSDates :: JSObject JSValue -> Result [JSValue] -> String -> 
                Result [[JSValue]]
getCMSDates jsO fixings path = returnCMSDates fixings
    where returnCMSDates :: Result [JSValue] ->  Result [[JSValue]]
          returnCMSDates rFx = do
              fx <- rFx
              let fx2 = read (encode fx) :: [Int]
              let dates = fmap getDatesCMS fx2 
              dates2 <- (checkAllOk dates)
              return dates2
          getDatesCMS :: Int -> Result [JSValue]              
          getDatesCMS fx = getArrayJS jsO (path ++ "/CMS_DATES_DICT/" ++ (show fx)) :: Result [JSValue]      
-- ------------------------------------------

buildFixedLeg :: JSObject JSValue -> String -> Result Leg
--buildFixedLeg jsO path = return legFixed
buildFixedLeg jsO path = returnFixedLeg startDateCoup endDateCoup payDateCoup remCapCoup 
                                        ratesCoup basisCoup computeModeCoup discCurve payRec
    where startDateCoup = getArrayJS jsO (path ++ "/PERIOD_START_DATES") :: Result [JSValue]
          endDateCoup = getArrayJS jsO (path ++ "/PERIOD_END_DATES") :: Result [JSValue]
          payDateCoup = getArrayJS jsO (path ++ "/PERIOD_PAYMENT_DATES") :: Result [JSValue]
          remCapCoup = getArrayJS jsO (path ++ "/PERIOD_REMAINING_CAPITALS") :: Result [JSValue]
          basisCoup = getValueJS jsO (path ++ "/RATE_CONVENTION_BASIS") :: Result JSValue
          computeModeCoup = getValueJS jsO (path ++ "/RATE_CONVENTION_COMPUTING_MODE") :: Result JSValue
          ratesCoup = getArrayJS jsO (path ++ "/PERIOD_APPLICABLE_RATES") :: Result [JSValue]
          discCurve = getValueJS jsO ("DEAL/DISCOUNT_CURVE") :: Result JSValue
          payRec = getValueJS jsO (path ++ "/LOAN_PAYOUT_SIGN") :: Result JSValue
          returnFixedLeg :: Result [JSValue] -> Result [JSValue] -> Result [JSValue] ->
                            Result [JSValue] -> Result [JSValue] -> Result JSValue ->
                            Result JSValue -> Result JSValue -> Result JSValue -> Result Leg
          returnFixedLeg rSDC rEDC rPDC rRCC rRC rBC rCMC rDC rPR = do
              sDC <- rSDC 
              eDC <- rEDC 
              pDC <- rPDC 
              rCC <- rRCC 
              rC <- rRC 
              bC <- rBC 
              cMC <- rCMC 
              dC <- rDC 
              pR <- rPR 
              let sDC2 = read (encode sDC) :: [Int] 
              let eDC2 = read (encode eDC) :: [Int] 
              let pDC2 = read (encode pDC) :: [Int] 
              let rCC2 = read (encode rCC) :: [Double] 
              let rC2 = read (encode rC) :: [Double] 
              let bC2 = decodeBasis (read (encode bC) :: Int)
              let cMC2 = decodeComputeMode (read (encode cMC) :: Int)
              let dC2 = read (encode dC) :: String
              let pR2 = decodePayerReceiver (read (encode pR) :: Int)
              let couponsList = getZipList $ buildCoupon <$> ZipList sDC2 <*> ZipList eDC2 <*> ZipList pDC2 
                                         <*> ZipList rCC2 <*> ZipList rC2 <*> ZipList (repeat bC2) 
                                         <*> ZipList (repeat cMC2)
              return (FixedLeg {coupons = couponsList, discCurve = dC2, legPayerReceiver = pR2})
              where
                  buildCoupon sDC eDC pDC rCC rC bC cMC = returnCoupon sDC eDC pDC rCC rC bC cMC                     
                  returnCoupon sDC eDC pDC rCC rC bC cMC = Fixed {cpStartDate = sDC, cpEndDate = eDC, cpPayDate = pDC, 
                                                                  cpYearFrac = 0.0, cpRemainingCapital = rCC, fxRate = rC,
                                                                  cpConvention = (cMC, bC), fxDiscFactor = 0.0}
-- ------------------------------------------
buildDealInfo :: JSObject JSValue -> Result DealInfo
buildDealInfo jsO = returnDealInfo portf evDate isPr flxType blckLabel
    where portf = getValueJS jsO "DEAL/DEAL_PORTFOLIO_LABEL" :: Result JSValue
          evDate = getValueJS jsO "DEAL/DEAL_TRADE_SETTLEMENT_DATE" :: Result JSValue
          isPr = getValueJS jsO "DEAL/DEAL_IN_PRICING_ENVIRONMENT" :: Result JSValue
          flxType = getValueJS jsO "DEAL/FLEX/0/TYPE" :: Result JSValue
          blckLabel = getValueJS jsO "DEAL/FLEX/0/BLOCK_LABEL" :: Result JSValue
          returnDealInfo :: Result JSValue -> Result JSValue -> Result JSValue ->
                            Result JSValue -> Result JSValue -> Result DealInfo
          returnDealInfo (Ok pf) (Ok eD) (Ok iP) (Ok fT) (Ok bL) = 
              Ok DealInfo {portfolio = pf2, evalDate = eD2, 
                isPricingMode = if (iP2 == 1) then True else False, flex = flx}
              where pf2 = read (encode pf) :: String
                    eD2 = read (encode eD) :: Int
                    iP2 = read (encode iP) :: Int
                    fT2 = read (encode fT) :: String
                    bL2 = read (encode bL) :: String
                    flx = Flex {flexType = fT2, blockLabel = bL2}  
          returnDealInfo a b c d e = Error ((getErr a) ++ (getErr b) ++ (getErr c) ++ (getErr d) ++ (getErr e))
-- ------------
buildModelParams :: JSObject JSValue -> Result Deal -> Result ModelParameters
buildModelParams jsO rDeal = returnModelParams params 
    where params = buildParams jsO rDeal
          returnModelParams :: Result [Parameters] -> Result ModelParameters
          returnModelParams rParams = do
              params <- rParams
              return ModelParameters {parameters = params}
-- ------------
buildParams :: JSObject JSValue -> Result Deal -> Result [Parameters]
buildParams jsO rDeal = do
    deal <- rDeal
    let product = dealProduct deal    
    let rParameters = case product of Swap _ l1 l2 _ -> do p1 <- (buildParamsLeg jsO l1 [])
                                                           p2 <- (buildParamsLeg jsO l2 p1)
                                                           return (p1 ++ p2)
                                      Option _ l _ -> do p <- (buildParamsLeg jsO l [])
                                                         return p
    parameters <- rParameters                                                            
    return parameters
    where buildParamsLeg :: JSObject JSValue -> Leg -> [Parameters] -> Result [Parameters] 
          buildParamsLeg jsO VariableLeg {coupons = cs, discCurve = dC,
                        legIndex = lI, legPayerReceiver = pR} ps = buildModParamsPerModel jsO (varModel (cs!!0)) lI ps
          buildParamsLeg jsO x y = Ok []                
-- ------------
buildModParamsPerModel :: JSObject JSValue -> Model -> String -> [Parameters] -> Result [Parameters]
buildModParamsPerModel jsO (HaganReplicationSABRRBS2 _ _ _ _ _ _ _ _ _) index params = returnModParams rAtmVolExp rAtmVolTen rAtmVolMatrix
                                                                                rSabrExp rSabrTen rBetaMatrix rRhoMatrix rVolOfVolMatrix
                                                                                rRbs2ExtrapExp rRbs2ExtrapTen rRbs2KMinusExtrapExp rRbs2KMinusExtrapTen
                                                                                rRbs2KExtrapExp rRbs2KExtrapTen rRbs2LeftExtrapMatrix
                                                                                rRbs2LeftStrikeMatrix rRbs2RightExtrapMatrix rRbs2RightStrikeMatrix
                                                                                rKappaTen rKappaValues
    where rAtmVolExp = if checkSabr then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/ATMVOL_EXPIRIES") :: Result [JSValue]
          rAtmVolTen = if checkSabr then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/ATMVOL_TENORS") :: Result [JSValue]
          rAtmVolMatrix = if checkSabr then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/ATMVOL_MATRIX") :: Result [[JSValue]] 
          rSabrExp = if checkSabr then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/SABR_EXPIRIES") :: Result [JSValue]
          rSabrTen = if checkSabr then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/SABR_TENORS") :: Result [JSValue]
          rBetaMatrix = if checkSabr then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/BETA_MATRIX") :: Result [[JSValue]] 
          rRhoMatrix = if checkSabr then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/RHO_MATRIX") :: Result [[JSValue]] 
          rVolOfVolMatrix = if checkSabr then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/VOLOFVOL_MATRIX") :: Result [[JSValue]]           
          rRbs2ExtrapExp = if checkRBS2 then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/RBS2_EXTRAP_EXPIRIES") :: Result [JSValue]
          rRbs2ExtrapTen = if checkRBS2 then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/RBS2_EXTRAP_TENORS") :: Result [JSValue] 
          rRbs2KMinusExtrapExp = if checkRBS2 then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/RBS2_KMINUS_EXTRAP_EXPIRIES") :: Result [JSValue]
          rRbs2KMinusExtrapTen = if checkRBS2 then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/RBS2_KMINUS_EXTRAP_TENORS") :: Result [JSValue]
          rRbs2KExtrapExp = if checkRBS2 then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/RBS2_K_EXTRAP_EXPIRIES") :: Result [JSValue] 
          rRbs2KExtrapTen = if checkRBS2 then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/RBS2_K_EXTRAP_TENORS") :: Result [JSValue] 
          rRbs2LeftExtrapMatrix = if checkRBS2 then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/RBS2_LEFT_EXTRAP_MATRIX") :: Result [[JSValue]] 
          rRbs2LeftStrikeMatrix = if checkRBS2 then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/RBS2_LEFT_STRIKE_MATRIX") :: Result [[JSValue]]
          rRbs2RightExtrapMatrix = if checkRBS2 then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/RBS2_RIGHT_EXTRAP_MATRIX") :: Result [[JSValue]] 
          rRbs2RightStrikeMatrix = if checkRBS2 then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/RBS2_RIGHT_STRIKE_MATRIX") :: Result [[JSValue]]
          rKappaTen = if checkKappa then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/KAPPA_TENORS") :: Result [JSValue] 
          rKappaValues = if checkKappa then Ok [] else getArrayJS jsO ("MODEL_PARAMETERS/KAPPA_VALUES") :: Result [JSValue] 
          checkSabr = (length (filter fSabr params)) > 0 where fSabr SABR {paramsIndex=index,vatmSABR=_,betaSABR=_,rhoSABR=_,volOfVolSABR=_} = True
                                                               fSabr x = False
          checkRBS2 = (length (filter fRbs2 params)) > 0 where fRbs2 RBS2 {paramsIndex=index,rightStrike=_,rightParams=_,leftStrike=_,leftParams=_} = True
                                                               fRbs2 x = False
          checkKappa = (length (filter fKappa params)) > 0 where fKappa KAPPA {paramsIndex=index,kTenors=_,kValues=_} = True
                                                                 fKappa x = False
          returnModParams :: Result [JSValue] -> Result [JSValue] -> Result [[JSValue]] -> Result [JSValue] ->
                             Result [JSValue] -> Result [[JSValue]] -> Result [[JSValue]] -> Result [[JSValue]] ->
                             Result [JSValue] -> Result [JSValue] -> Result [JSValue] -> Result [JSValue] ->
                             Result [JSValue] -> Result [JSValue] -> Result [[JSValue]] -> Result [[JSValue]] ->
                             Result [[JSValue]] -> Result [[JSValue]] -> Result [JSValue] -> Result [JSValue] ->
                             Result [Parameters]
          returnModParams rAtmVolExp rAtmVolTen rAtmVolMatrix
                          rSabrExp rSabrTen rBetaMatrix rRhoMatrix rVolOfVolMatrix
                          rRbs2ExtrapExp rRbs2ExtrapTen rRbs2KMinusExtrapExp rRbs2KMinusExtrapTen
                          rRbs2KExtrapExp rRbs2KExtrapTen rRbs2LeftExtrapMatrix
                          rRbs2LeftStrikeMatrix rRbs2RightExtrapMatrix rRbs2RightStrikeMatrix 
                          rKappaTen rKappaValues = do --
              atmVolExp <- rAtmVolExp
              atmVolTen <- rAtmVolTen
              atmVolMatrix <- rAtmVolMatrix
              sabrExp <- rSabrExp
              sabrTen <- rSabrTen
              betaMatrix <- rBetaMatrix
              rhoMatrix <- rRhoMatrix
              volOfVolMatrix <- rVolOfVolMatrix      
              rbs2ExtrapExp <- rRbs2ExtrapExp
              rbs2ExtrapTen <- rRbs2ExtrapTen
              rbs2KMinusExtrapExp <- rRbs2KMinusExtrapExp
              rbs2KMinusExtrapTen <- rRbs2KMinusExtrapTen
              rbs2KExtrapExp <- rRbs2KExtrapExp
              rbs2KExtrapTen <- rRbs2KExtrapTen
              rbs2LeftExtrapMatrix <- rRbs2LeftExtrapMatrix
              rbs2LeftStrikeMatrix <- rRbs2LeftStrikeMatrix
              rbs2RightExtrapMatrix <- rRbs2RightExtrapMatrix
              rbs2RightStrikeMatrix <- rRbs2RightStrikeMatrix
              kappaTen <- rKappaTen
              kappaValues <- rKappaValues
              
              let atmVolExp2 = read (encode atmVolExp) :: [Double]
              let atmVolTen2 = read (encode atmVolTen) :: [Double] 
              let atmVolMatrix2 = read (encode atmVolMatrix) :: [[Double]]
              let sabrExp2 = read (encode sabrExp) :: [Double] 
              let sabrTen2 = read (encode sabrTen) :: [Double] 
              let betaMatrix2 = read (encode betaMatrix) :: [[Double]]
              let rhoMatrix2 = read (encode rhoMatrix) :: [[Double]]      
              let volOfVolMatrix2 = read (encode volOfVolMatrix) :: [[Double]]   
              let rbs2ExtrapExp2 = read (encode rbs2ExtrapExp) :: [Double]
              let rbs2ExtrapTen2 = read (encode rbs2ExtrapTen) :: [Double]
              let rbs2KMinusExtrapExp2 = read (encode rbs2KMinusExtrapExp) :: [Double]
              let rbs2KMinusExtrapTen2 = read (encode rbs2KMinusExtrapTen) :: [Double]
              let rbs2KExtrapExp2 = read (encode rbs2KExtrapExp) :: [Double]
              let rbs2KExtrapTen2 = read (encode rbs2KExtrapTen) ::[Double]
              let rbs2LeftExtrapMatrix2 = read (encode rbs2LeftExtrapMatrix) :: [[Double]]   
              let rbs2LeftStrikeMatrix2 = read (encode rbs2LeftStrikeMatrix) :: [[Double]]   
              let rbs2RightExtrapMatrix2 = read (encode rbs2RightExtrapMatrix) :: [[Double]]   
              let rbs2RightStrikeMatrix2 = read (encode rbs2RightStrikeMatrix) :: [[Double]]   
              let kappaTen2 = read (encode kappaTen) :: [Double]
              let kappaValues2 = read (encode kappaValues) :: [Double]
              
              let sabr = SABR {paramsIndex = index, 
                               vatmSABR = ParamsMatrix{expiries = atmVolExp2,tenors = atmVolTen2, matrix = atmVolMatrix2}, 
                               betaSABR = ParamsMatrix{expiries = sabrExp2,tenors = sabrTen2, matrix = betaMatrix2}, 
                               rhoSABR = ParamsMatrix{expiries = sabrExp2,tenors = sabrTen2, matrix = rhoMatrix2}, 
                               volOfVolSABR = ParamsMatrix{expiries = sabrExp2,tenors = sabrTen2, matrix = volOfVolMatrix2}}
              let rbs2 = RBS2 {paramsIndex = index, 
                               rightStrike = ParamsMatrix{expiries = rbs2KExtrapExp2,tenors = rbs2KExtrapTen2, matrix = rbs2RightStrikeMatrix2}, 
                               rightParams = ParamsMatrix{expiries = rbs2ExtrapExp2,tenors = rbs2ExtrapTen2, matrix = rbs2RightExtrapMatrix2}, 
                               leftStrike = ParamsMatrix{expiries = rbs2KMinusExtrapExp2,tenors = rbs2KMinusExtrapTen2, matrix = rbs2LeftStrikeMatrix2}, 
                               leftParams = ParamsMatrix{expiries = rbs2ExtrapExp2,tenors = rbs2ExtrapTen2, matrix = rbs2LeftExtrapMatrix2}}
              
              let kappa = KAPPA {paramsIndex = index, kTenors = kappaTen2, kValues = kappaValues2} 
              let checkSabr = (length (filter fSabr params)) > 0 where fSabr SABR {paramsIndex=index,vatmSABR=_,betaSABR=_,rhoSABR=_,volOfVolSABR=_} = True
                                                                       fSabr x = False
              let checkRBS2 = (length (filter fRbs2 params)) > 0 where fRbs2 RBS2 {paramsIndex=index,rightStrike=_,rightParams=_,leftStrike=_,leftParams=_} = True
                                                                       fRbs2 x = False
              let checkKappa = (length (filter fKappa params)) > 0 where fKappa KAPPA {paramsIndex=index,kTenors=_,kValues=_} = True
                                                                         fKappa x = False
              return   ((if checkSabr then [] else [sabr]) ++ 
                       (if checkRBS2 then [] else [rbs2]) ++ 
                       (if checkKappa then [] else [kappa]) )
              
buildModParamsPerModel jsO model index params = Ok [] 
           
-- ------------
buildMktParams :: JSObject JSValue -> Result MarketData
buildMktParams jsO = returnMktData curves volasCf volasSw
    where curves = buildCurves jsO
          volasCf = buildVolCapFloor jsO
          volasSw = buildVolSwaption jsO
          returnMktData :: Result [Curve] -> Result [CapFloorVol] -> 
                           Result [SwaptionVol] -> Result MarketData
          returnMktData (Ok cvs) (Ok vlsCF) (Ok vlsSw) = 
              Ok MarketData {curves = cvs, capFloorVols = vlsCF, swaptionVols = vlsSw}
          returnMktData x y z = Error ((getErr x) ++ (getErr y) ++ (getErr z))
-- ------------
buildVolSwaption :: JSObject JSValue -> Result [SwaptionVol]
buildVolSwaption jsO = returnVols curr
    where curr = [EUR]
          returnVols :: [Currency] -> Result [SwaptionVol]
          returnVols c = checkAllOk lResultVols
              where lResultVols = fmap (buildVolSwaption1 jsO) c
-- -------
buildVolSwaption1 :: JSObject JSValue -> Currency -> Result SwaptionVol
buildVolSwaption1 jsO curr = returnVolSw matrix optMat strikes swapMat
   where path = "MARKET_PARAMETERS/SWAPTION_VOLATILITIES/" ++ (show curr) ++ "-IBOR"
         matrix = getArrayJS jsO (path ++ "/MATRIX") 
                     :: Result [[[JSValue]]]
         optMat = getArrayJS jsO (path ++ "/OPTION_MATURITIES") :: Result [JSValue]
         strikes = getArrayJS jsO (path ++ "/STRIKES") :: Result [JSValue]
         swapMat = getArrayJS jsO (path ++ "/SWAP_MATURITIES") :: Result [JSValue]
         returnVolSw :: Result [[[JSValue]]] -> Result [JSValue] ->
                      Result [JSValue] -> Result [JSValue] -> Result SwaptionVol
         returnVolSw (Ok m) (Ok oM) (Ok s) (Ok sM) = 
             Ok SwaptionVol {swCurr = curr, swMatrix = m2,
             swOptMat = oM2, swStrikes = s2, swSwapMat = sM2}
             where m2 = read (encode m) :: [[[Double]]]
                   oM2 = read (encode oM) :: [Int]
                   s2 = read (encode s) :: [Double]
                   sM2 = read (encode sM) :: [[Int]]
         returnVolSw a b c d = Error ((getErr a) ++ (getErr b) ++ (getErr c) ++ (getErr d))

-- ------------
buildVolCapFloor :: JSObject JSValue -> Result [CapFloorVol]
buildVolCapFloor jsO = returnVols indx1 indx2
    where indx1 = getValueJS jsO "DEAL/LEGS/(0, 0)/INDEX_NAME" :: Result JSValue
          indx2 = getValueJS jsO "DEAL/LEGS/(0, 1)/INDEX_NAME" :: Result JSValue
          returnVols :: Result JSValue -> Result JSValue -> Result [CapFloorVol]
          returnVols (Ok i1) (Ok i2) = checkAllOk lResultVols
              where lResultVols = fmap (buildVolCapFloor1 jsO) lStringIndx
                    lStringIndx = [read (encode i1) :: String, 
                                   read (encode i2) :: String] 
          returnVols (Ok i1) y = checkAllOk lResultCvs
              where lResultCvs = fmap (buildVolCapFloor1 jsO) lStringIndx
                    lStringIndx = [read (encode i1) :: String]
          returnVols x (Ok i2) = checkAllOk lResultCvs
              where lResultCvs = fmap (buildVolCapFloor1 jsO) lStringIndx
                    lStringIndx = [read (encode i2) :: String]
          returnVols x y = Error ((getErr x) ++ (getErr y))
-----------
buildVolCapFloor1 :: JSObject JSValue -> String -> Result CapFloorVol
buildVolCapFloor1 jsO index = returnVolCF matrix optMat strikes
   where path = "MARKET_PARAMETERS/CAPFLOOR_VOLATILITIES/" ++ index
         matrix = getArrayJS jsO (path ++ "/MATRIX") 
                     :: Result [[JSValue]]
         optMat = getArrayJS jsO (path ++ "/OPTION_MATURITIES") :: Result [JSValue]
         strikes = getArrayJS jsO (path ++ "/STRIKES") :: Result [JSValue]
         returnVolCF :: Result [[JSValue]] -> Result [JSValue] ->
                      Result [JSValue] -> Result CapFloorVol
         returnVolCF (Ok m) (Ok oM) (Ok s) = 
             Ok CapFloorVol {index = index, cfvMatrix = m2,
             cfvOptMat = oM2, cfvStrikes = s2}
             where m2 = read (encode m) :: [[Double]]
                   oM2 = read (encode oM) :: [Int]
                   s2 = read (encode s) :: [Double]
         returnVolCF a b c = Error ((getErr a) ++ (getErr b) ++ (getErr c))

-- ------------
buildCurves :: JSObject JSValue -> Result [Curve]
buildCurves jsO = returnCurves discCurve estCurves
    where discCurve = getValueJS jsO "DEAL/DISCOUNT_CURVE" :: Result JSValue
          estCurves = getArrayJS jsO "DEAL/ESTIMATION_CURVES" :: Result [JSValue]
          curr = EUR
          returnCurves :: Result JSValue -> Result [JSValue] -> Result [Curve]
          returnCurves (Ok dCurve) (Ok estCurves) = checkAllOk lResultCvs
              where lResultCvs = fmap (buildCurve jsO curr) lStringCvs
                    lStringCvs = strDCurve : strEstCurves
                    strDCurve =  read (encode dCurve) :: String
                    strEstCurves =  read (encode estCurves) :: [String] 
          returnCurves x y = Error ((getErr x) ++ (getErr y))
                    
-- --------------------------------                          
buildCurve :: JSObject JSValue -> Currency -> String -> Result Curve
buildCurve jsO curr name = returnCurve coumpConv num den bCurve intForm
                           rfDt sprFormula val2Int mats dfs
   where path = "MARKET_PARAMETERS/DISCOUNT_FACTOR_CURVE/" 
                ++ (show curr) ++ "/" ++ name
         coumpConv = getValueJS jsO (path ++ "/CONVENTION_COMPUTING_MODE") 
                     :: Result JSValue
         num = getValueJS jsO (path ++ "/CONVENTION_NUMERATOR") :: Result JSValue
         den = getValueJS jsO (path ++ "/CONVENTION_DENOMINATOR") 
               :: Result JSValue
         bCurve = getValueJS jsO (path ++ "/BASE_CURVE") :: Result JSValue
         intForm = getValueJS jsO (path ++ "/INTERPOLATION_FORMULA") 
                   :: Result JSValue
         rfDt = getValueJS jsO (path ++ "/REFERENCE_DATE") :: Result JSValue
         sprFormula = getValueJS jsO (path ++ "/SPREAD_CURVE_FORMULA") 
                      :: Result JSValue
         val2Int = getValueJS jsO (path ++ "/VALUE_TO_INTERPOLATE") 
                   :: Result JSValue
         mats = getArrayJS jsO (path ++ "/PILLAR_MATURITIES") :: Result [JSValue]
         dfs = getArrayJS jsO (path ++ "/DISCOUNT_FACTORS") :: Result [JSValue]
         returnCurve :: Result JSValue -> Result JSValue -> Result JSValue ->
                        Result JSValue -> Result JSValue -> Result JSValue ->
                        Result JSValue -> Result JSValue -> Result [JSValue] ->
                        Result [JSValue] -> Result Curve
         returnCurve (Ok cC) (Ok n) (Ok d) (Ok bC) (Ok iF) 
                     (Ok rD) (Ok sF) (Ok vI) (Ok ms) (Ok dFs) = 
             Ok Curve {nameCurve = name, currencyCurve = curr,
             conventionCurve = conv, baseCurve = bC2,
             discountFactors = dFs2, interpolationFormula = iF2,
             pillarMaturities = ms2, refDate = rD2, 
             spreadCurveFormula = sF2, value2Interpolate = vI2}
             where conv = (read cC2 :: CoumpondingConvention, fracConv)
                   fracConv = read (n2 ++ d2) :: FracConvention
                   cC2 = read (encode cC) :: String
                   n2 = read (encode n) :: String
                   d2 = read (encode d) :: String
                   bC2 = read (encode bC) :: String
                   iF2 = read (encode iF) :: String
                   rD2 = read (encode rD) :: Int
                   sF2 = read (encode sF) :: String
                   vI2 = read (encode vI) :: String
                   ms2 = read (encode ms) :: [Int]
                   dFs2 = read (encode dFs) :: [Double]
         returnCurve a b c d e f g h i j = Error ((getErr a) ++ (getErr b) ++ (getErr c) ++ (getErr d) ++ (getErr e) ++ (getErr f) ++ (getErr g) ++ (getErr h) ++ (getErr i) ++ (getErr j)) 


--------------------------------------------------------
decodeBasis :: Int -> FracConvention
decodeBasis 0 = ACT360
decodeBasis 1 = ACT360
decodeBasis 2 = ACT360
decodeBasis 3 = ACT360
decodeBasis 4 = ACT360
decodeBasis 5 = ACT360

decodeComputeMode :: Int -> CoumpondingConvention
decodeComputeMode 0 = LIN

decodePayerReceiver :: Int -> PayerReceiver
decodePayerReceiver 0 = PAYER
decodePayerReceiver 1 = RECEIVER

decodeModel :: String -> Model
decodeModel "VANILLACMS" = HaganReplicationSABRRBS2 {forward = 0.0, alpha = 0.0, beta = 0.0, rho = 0.0,
                                               volOfVol = 0.0, xPlus = 0.0, xMinus = 0.0, 
                                               nu = 0.0, mu = 0.0}

--------------------------------------------------------
legFixed = FixedLeg (replicate 2 cpFixed) "" PAYER
cpFixed = Fixed {cpStartDate = 1, cpEndDate = 1, cpPayDate = 1, cpYearFrac = 1.0, 
                 cpRemainingCapital = 1.0, cpConvention = (LIN, ACT360), 
                 fxRate = 1.0, fxDiscFactor = 1.0}

                 
    
    
    
