import System.IO  
import Text.JSON
import Text.JSON.Generic
import Text.JSON.Types
import Types
import ILInterface
import ProcessJSON


 
main = do
    -- This is your data source
    --let ddbb = "../TestJSON/7023936.in"
    --let ddbb = "../TestJSON/7023936_fixed.in"
    let ddbb = "../TestJSON/6435516_cap.in"
    
    -- You know what product you want, you have different builders
    jsonInput <- buildJSON ddbb
    writeFile "../Logs/input.json" jsonInput
    ------------------------------------------------------------------
    ------------------------------------------------------------------
    ------------------------------------------------------------------
    -- Process
    let jsonOutput = processJSON jsonInput
    writeFile "../Logs/output.json" jsonOutput 
    return ()
    
    

