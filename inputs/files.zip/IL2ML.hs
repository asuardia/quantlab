import System.IO  
import Text.JSON
import Text.JSON.Generic
import Text.JSON.Types
import Types
import ILInterface
import ProcessJSON


 
main = do
    -- This is your data source
    --let ddbb = "../TestJSON/7023936.in"
    --let ddbb = "../TestJSON/7023936_fixed.in"
    let ddbb = "../TestJSON/6435516_cap.in"
    
    -- You know what product you want, you have different builders
    jsonInput <- buildJSON ddbb
    writeFile "../Logs/input.json" jsonInput
    
    let input = decodeJSON jsonInput :: Input
    let deal = inputDeal input
    let product = dealProduct deal
    let marketData = inputMarket input
    let modelParameters = inputModelParams input
    -- Process
    let mktDatML = paintMktDatML marketData
    
    writeFile "../Logs/mktData.m" mktDatML
    return ()
    
paintMktDatML :: MarketData -> String
paintMktDatML mkt = cvs ++ vols ++ swVols
    where cvs = concat $ fmap paintCurveML (curves mkt)
          vols = concat $ fmap paintVolCFML (capFloorVols mkt)
          swVols = concat $ fmap paintSwaptionVolML (swaptionVols mkt)
           
paintCurveML :: Curve -> String    
paintCurveML cv =  filter (\x -> x /= '-') $ (nameCurve cv) ++ " = [" ++ 
                      concat (zipWith paintPair (pillarMaturities cv) (discountFactors cv)) ++ "];"
    where
        paintPair :: Int -> Double -> String      
        paintPair pm df = show pm ++ " " ++ show df ++ ";"
                
paintSwaptionVolML :: SwaptionVol -> String    
paintSwaptionVolML v = strikes ++ exp ++ ten ++ (concat $ fmap paintSheet iv)
    where
        iv = zip [1,2..] (swMatrix v)
        paintSheet :: (Int, [[Double]]) -> String      
        paintSheet ish = "SwaptionVol(" ++ show (fst ish) ++ ",:,:) = [" ++ (concat $ fmap paintSheet2 (snd ish)) ++ "];"
        paintSheet2 l = (concat $ fmap (++" ") (fmap show l)) ++ ";"
        strikes = "swStrikes=" ++ (show (swStrikes v)) ++ "';"
        exp = "swSwapMat=" ++ (show ((swSwapMat v)!!0)) ++ "';"
        ten = "swOptMat=" ++ (show (swOptMat v)) ++ "';"
        
paintVolCFML :: CapFloorVol -> String    
paintVolCFML v =  strikes ++ exp ++ "VolCF_" ++ (filter (\x -> x /= '-') $ (index v)) ++ " = [" ++ 
                      (concat $ fmap paintSheet2 (cfvMatrix v)) ++ "];"
    where
        paintSheet2 l = (concat $ fmap (++" ") (fmap show l)) ++ ";"
        strikes = "cfvStrikes=" ++ (show (cfvStrikes v)) ++ "';"
        exp = "cfvOptMat=" ++ (show (cfvOptMat v)) ++ "';"
        
        